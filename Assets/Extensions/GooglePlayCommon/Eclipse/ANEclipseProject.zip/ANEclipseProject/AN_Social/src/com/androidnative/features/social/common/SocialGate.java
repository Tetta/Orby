package com.androidnative.features.social.common;

import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.FileOutputStream;
import java.util.ArrayList;
import java.util.List;

import android.annotation.SuppressLint;
import android.content.Context;
import android.content.Intent;
import android.content.pm.ResolveInfo;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.net.Uri;
import android.provider.MediaStore.Images;
import android.support.v4.content.FileProvider;
import android.util.Log;


import com.androidnative.features.social.utils.Base64;
import com.androidnative.features.social.utils.SocialConf;




public class SocialGate {

	public static Uri ShredUri = null;
	
	@SuppressLint("NewApi")
	public static void StartShareIntent(String caption, String message, String subject, String filters) {
		Log.d("AndroidNative", " SocialGate Share ");
		
		Intent shareIntent = new Intent();
		shareIntent.setAction(Intent.ACTION_SEND);
		shareIntent.setType("text/plain");
		shareIntent.putExtra(Intent.EXTRA_TEXT, message);
		shareIntent.putExtra(Intent.EXTRA_SUBJECT, subject);
		StartIntent(shareIntent, caption, filters);
	}
	
	
	@SuppressLint("NewApi")
	public static void StartShareIntentMedia(String caption, String message,  String subject, String media,  String filters) {
		
		
		byte[] byteArray;
		try {
			byteArray = Base64.decode(media);

		
			
			Uri image =  getImageUri(SocialConf.GetLauncherActivity(), byteArray);
			

			Intent shareIntent = new Intent();
			shareIntent.setAction(Intent.ACTION_SEND);
			shareIntent.setType("image/*");
			shareIntent.putExtra(Intent.EXTRA_TEXT, message);
			shareIntent.putExtra(Intent.EXTRA_SUBJECT, subject);
			shareIntent.putExtra(Intent.EXTRA_STREAM, image);
			shareIntent.addFlags(Intent.FLAG_ACTIVITY_CLEAR_WHEN_TASK_RESET);
		    shareIntent.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION);
			
			StartIntent(shareIntent, caption, filters);
			
			
		
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
	}
	
	@SuppressLint("NewApi")
	public static void SendMailWithImage(String caption, String message,  String subject, String email, String media) {
		try {
			byte[] byteArray;
			byteArray = Base64.decode(media);
			
			
			
	
		//	
			Uri image =  getImageUri(SocialConf.GetLauncherActivity(), byteArray);
			
			
			
		
			Intent shareIntent = new Intent();
			shareIntent.setAction(Intent.ACTION_SEND);
			shareIntent.setType("image/*");
			
			shareIntent.putExtra(android.content.Intent.EXTRA_EMAIL,new String[] { email });
			shareIntent.putExtra(Intent.EXTRA_TEXT, message);
			shareIntent.putExtra(Intent.EXTRA_SUBJECT, subject);
			shareIntent.putExtra(Intent.EXTRA_STREAM, image);
			shareIntent.addFlags(Intent.FLAG_ACTIVITY_CLEAR_WHEN_TASK_RESET);
		    shareIntent.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION);

			
			
			
			StartIntent(shareIntent, caption, "mail");
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
	
	public static void SendMail(String caption, String message,  String subject, String emails) {
		
		Intent shareIntent = new Intent();
		shareIntent.setAction(Intent.ACTION_SEND);
		shareIntent.setType("text/plain");
		shareIntent.putExtra(android.content.Intent.EXTRA_EMAIL,  emails.split(",") );
		
		shareIntent.putExtra(Intent.EXTRA_TEXT, message);
		shareIntent.putExtra(Intent.EXTRA_SUBJECT, subject);
		

		StartIntent(shareIntent, caption, "mail");

		
	}
	
	
	
	@SuppressLint({ "NewApi", "DefaultLocale" })
	private static void StartIntent(Intent shareIntent, String caption, String filters) {
		
		try {
			if(filters.isEmpty()) {
				SocialConf.GetLauncherActivity().startActivity(Intent.createChooser(shareIntent, caption));
			} else {
				ArrayList<String> filtersArray = new ArrayList<String>();
				String[] result = filters.split(",");

				for (String id : result) {
					filtersArray.add(id);
				}
				
				// gets the list of intents that can be loaded.
			    List<ResolveInfo> resInfo = SocialConf.GetLauncherActivity().getPackageManager().queryIntentActivities(shareIntent, 0);
			    if (!resInfo.isEmpty()){
			        for (ResolveInfo info : resInfo) {
			        	for(String filterPattern : filtersArray) {
			        		if (info.activityInfo.packageName.toLowerCase().contains(filterPattern) || info.activityInfo.name.toLowerCase().contains(filterPattern) ) {
				            	shareIntent.setPackage(info.activityInfo.packageName);
				            	
				            	
				            	if(ShredUri != null) {
				            		SocialConf.GetLauncherActivity().grantUriPermission(info.activityInfo.packageName, ShredUri, Intent.FLAG_GRANT_WRITE_URI_PERMISSION | Intent.FLAG_GRANT_READ_URI_PERMISSION);
				            	}

				            }
			        	}
			        	
			            
			        }

			        SocialConf.GetLauncherActivity().startActivity(Intent.createChooser(shareIntent, caption));
			    }
			    
			}
		}  catch (Exception ex) {
			Log.d("AndroidNative", "Got exception: " +  ex.getMessage());
			ex.printStackTrace();
		 }
		
		
	}
	
	@SuppressLint("NewApi") 
	 public static Uri getImageUri(Context inContext, byte[] byteArray) {
		 
		 try {
			
			 Log.d("AndroidNative", "Creating Share URI with external storage");
			 Bitmap bmp = BitmapFactory.decodeByteArray(byteArray, 0, byteArray.length);
			 
			 ByteArrayOutputStream bytes = new ByteArrayOutputStream();
			 bmp.compress(Bitmap.CompressFormat.JPEG, 100, bytes);
			 String path = Images.Media.insertImage(inContext.getContentResolver(), bmp, "Screenshot", null);
			 ShredUri = Uri.parse(path);
			 Log.d("AndroidNative", ShredUri.toString());
			 return  ShredUri;
			  
		 } catch (Exception ex) {
			 try {
				Log.d("AndroidNative", ex.getMessage());
				Log.d("AndroidNative", "Creating Share URI with local storage");
				File tempFile;
				tempFile = new File(inContext.getCacheDir(), "screen.png");
				FileOutputStream fos = new FileOutputStream(tempFile);
				fos.write(byteArray);
				fos.close();
				
				ShredUri = FileProvider.getUriForFile(SocialConf.GetLauncherActivity(),  SocialConf.GetLauncherActivity().getPackageName() +  ".fileprovider", tempFile);
				Log.d("AndroidNative", ShredUri.toString());
				return ShredUri;
				
			 } catch (Exception ex2) {
				 Log.d("AndroidNative", ex2.getMessage());
				 return Uri.parse(""); 
			 } 
		 }
	}
}

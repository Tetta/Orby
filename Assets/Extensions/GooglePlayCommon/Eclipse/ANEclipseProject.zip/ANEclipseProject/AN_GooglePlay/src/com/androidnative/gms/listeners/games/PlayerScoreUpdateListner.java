package com.androidnative.gms.listeners.games;

import android.util.Log;


import com.androidnative.gms.core.GameClientManager;
import com.google.android.gms.common.api.ResultCallback;
import com.google.android.gms.games.GamesStatusCodes;
import com.google.android.gms.games.leaderboard.Leaderboards;
import com.google.android.gms.games.leaderboard.Leaderboards.LoadPlayerScoreResult;
import com.unity3d.player.UnityPlayer;


public class PlayerScoreUpdateListner implements ResultCallback<Leaderboards.LoadPlayerScoreResult> {
	
	private int _span;
	private int _leaderboardCollection;
	private String _leaderboardId;

	
	public PlayerScoreUpdateListner(int span, int leaderboardCollection, String leaderboardId) {
		_span = span;
		_leaderboardId = leaderboardId;
		_leaderboardCollection = leaderboardCollection;
	}
	
	@Override
	public void onResult(LoadPlayerScoreResult res) {
		
		
		int statusCode = res.getStatus().getStatusCode();
		StringBuilder leaderboardsInfo = new StringBuilder();
		leaderboardsInfo.append(statusCode);
		
		
		if (statusCode == GamesStatusCodes.STATUS_OK) {
			leaderboardsInfo.append(GameClientManager.UNITY_SPLITTER);
			leaderboardsInfo.append(_span);
			leaderboardsInfo.append(GameClientManager.UNITY_SPLITTER);
			leaderboardsInfo.append(_leaderboardCollection);
			leaderboardsInfo.append(GameClientManager.UNITY_SPLITTER);
			leaderboardsInfo.append(_leaderboardId);
			leaderboardsInfo.append(GameClientManager.UNITY_SPLITTER);
			
			if(res.getScore() != null) {
				leaderboardsInfo.append(res.getScore().getRawScore());
				leaderboardsInfo.append(GameClientManager.UNITY_SPLITTER);
				leaderboardsInfo.append(res.getScore().getRank());
			} else {
				Log.d("AndroidNative", "No score: ");
				leaderboardsInfo.append("-1");
				leaderboardsInfo.append(GameClientManager.UNITY_SPLITTER);
				leaderboardsInfo.append("-1");
			}
			
			
		}
		
		
		UnityPlayer.UnitySendMessage(GameClientManager.PlAY_SERVICE_LISTNER_NAME, "OnPlayerScoreUpdated", leaderboardsInfo.toString());
		
	}

}

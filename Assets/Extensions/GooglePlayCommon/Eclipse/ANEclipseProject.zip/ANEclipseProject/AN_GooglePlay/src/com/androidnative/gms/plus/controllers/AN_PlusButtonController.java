package com.androidnative.gms.plus.controllers;

import java.util.HashMap;

import android.annotation.SuppressLint;
import android.util.Log;


import com.androidnative.gms.plus.models.AN_PlusButton;

@SuppressLint("UseSparseArrays") 
public class AN_PlusButtonController {
	
	private static HashMap<Integer, AN_PlusButton> buttons = new HashMap<Integer, AN_PlusButton>();
	
	
	public static void createPlusButton(int id, String url, int size, int annotation) {
		
		Log.d("AndroidNative", "created: " + id);
		AN_PlusButton b = new AN_PlusButton(id, url, size, annotation);
		buttons.put(id, b);
	}
	
	
	public static void setGravity(int gravity, int id) {
		if(buttons.containsKey(id)) {
			AN_PlusButton b = buttons.get(id);
			b.setGravity(gravity);
		} else {
			Log.d("AndroidNative", "AN_PlusButtonController setGravity: Button with id: " + id + " not found");
		}
	}
	

	public static void setPosition(int x, int y, int id) {
		
		if(buttons.containsKey(id)) {
			Log.d("AndroidNative", "SetPosition");
			AN_PlusButton b = buttons.get(id);
			b.SetPosition(x, y);
		} else {
			Log.d("AndroidNative", "AN_PlusButtonController setPosition: Button with id: " + id + " not found");
		}
		
	}
	
	
	public static void show(int id) {
		if(buttons.containsKey(id)) {
			AN_PlusButton b = buttons.get(id);
			b.Show();
		} else {
			Log.d("AndroidNative", "AN_PlusButtonController show: Button with id: " + id + " not found");
		}
	}
	
	
	public static void hide(int id) {
		
		
		if(buttons.containsKey(id)) {
			AN_PlusButton b = buttons.get(id);
			b.Hide();
		} else {
			Log.d("AndroidNative", "AN_PlusButtonController hide: Button with id : " + id + " not found");
		}
		
	}
	
	
	public static void refresh(int id) {
		if(buttons.containsKey(id)) {
			AN_PlusButton b = buttons.get(id);
			b.Refresh();
		} else {
			Log.d("AndroidNative", "AN_PlusButtonControllerrefresh : Button with id: " + id + " not found");
		}
	}
	
}

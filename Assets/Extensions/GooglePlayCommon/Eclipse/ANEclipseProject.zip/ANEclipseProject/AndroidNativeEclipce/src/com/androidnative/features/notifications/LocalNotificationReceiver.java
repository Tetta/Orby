package com.androidnative.features.notifications;

import android.annotation.SuppressLint;
import android.app.Notification;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.os.Bundle;
import android.support.v4.app.NotificationCompat;
import android.util.Log;

import com.androidnative.AndroidNativeBridge;

public class LocalNotificationReceiver extends BroadcastReceiver {

	
	@SuppressLint("NewApi")
	@Override
	public void onReceive(Context context, Intent intent) {
		
		Bundle extras 		= intent.getExtras();
		String title 		= extras.getString(LocalNotificationsController.TITILE_KEY);
    	String message 		= extras.getString(LocalNotificationsController.MESSAGE_KEY);
    	int notificationId	= extras.getInt(LocalNotificationsController.ID_KEY);
    	    	 
    	NotificationManager  mNotificationManager = (NotificationManager) context.getSystemService(Context.NOTIFICATION_SERVICE);

    
    	Intent appIntent = new Intent(context, AndroidNativeBridge.class);
    	appIntent.putExtra(LocalNotificationsController.ID_KEY, notificationId);
        PendingIntent contentIntent = PendingIntent.getActivity(context, notificationId, appIntent, PendingIntent.FLAG_ONE_SHOT | PendingIntent.FLAG_CANCEL_CURRENT);
        
        Log.d("AndroidNative", "Notification recived" );
        NotificationCompat.Builder mBuilder = new NotificationCompat.Builder(context)
	        .setSmallIcon(0x7f020000)//Unity Game Icon
	        .setDefaults(Notification.DEFAULT_SOUND | Notification.DEFAULT_VIBRATE | Notification.DEFAULT_LIGHTS)
	        .setContentTitle(title)
	        .setStyle(new NotificationCompat.BigTextStyle()
	        .bigText(message))
	        .setContentText(message);

        mBuilder.setContentIntent(contentIntent).setAutoCancel(true);
        mNotificationManager.notify(notificationId, mBuilder.build());
        
	}
}

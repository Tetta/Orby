package com.androidnative.features;

import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.OutputStream;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Locale;

import android.annotation.SuppressLint;
import android.app.Activity;
import android.content.ContentResolver;
import android.content.ContentValues;
import android.content.Intent;
import android.graphics.Bitmap;
import android.graphics.Bitmap.CompressFormat;
import android.graphics.BitmapFactory;
import android.net.Uri;
import android.os.Bundle;
import android.os.Environment;
import android.provider.MediaStore;
import android.provider.MediaStore.Images;
import android.util.Log;

import com.androidnative.AndroidNativeBridge;
import com.androidnative.billing.util.Base64;
import com.kbeanie.imagechooser.api.ChooserType;
import com.kbeanie.imagechooser.api.ChosenImage;
import com.kbeanie.imagechooser.api.ImageChooserListener;
import com.kbeanie.imagechooser.api.ImageChooserManager;
import com.unity3d.player.UnityPlayer;

@SuppressLint("SimpleDateFormat")
public class CameraAPI implements ImageChooserListener {
	

	private static int RESULT_IMAGE_CAPTURE = 2930;
	private static String CAMERA_SERVICE_LISTNER_NAME = "AndroidCamera";

	private static ImageChooserManager imageChooserManager;
    private static CameraAPI _instance = null;
    
    
    private static boolean TakeFullSizePhoto = true;
    private static String GalleryFolderName = null;
    private static int MaxImageAllowedSize = 1024;
    
    
	public static CameraAPI GetInstance() {
		if(_instance == null) {
			_instance =  new CameraAPI();
		}
		
		return _instance;
	}
	
	public void Init(String folderName, int maxSize, int mode) {
		GalleryFolderName = folderName;
		MaxImageAllowedSize = maxSize;
		
		if(mode != 0) {
			TakeFullSizePhoto = true;
		} else {
			TakeFullSizePhoto = false;
		}
		
	}
	
	
	
	@SuppressLint("NewApi")
	public void SaveToGalalry(String ImageData, String name) {
		byte[] byteArray;
		try {
			
			byteArray = Base64.decode(ImageData);
			Bitmap bmp;
			bmp = BitmapFactory.decodeByteArray(byteArray, 0, byteArray.length);
			
			OutputStream fOut = null;
			
			String appDirectoryName = GalleryFolderName;// "XWZ";
			Log.d("AndroidNative", "appDirectoryName: " + appDirectoryName);
		    File imageRoot = new File(Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_PICTURES), appDirectoryName);
		   
		    
		    imageRoot.mkdirs();
		    
		    String FileName = name + ".jpg";
		    File file = new File(imageRoot, FileName);
		    int index = 1;
		    while(file.exists()) {
		    	
		    	FileName = name + Integer.toString(index) + ".jpg";;
		    	file = new File(imageRoot, FileName);
		    	index ++;
		    }
		    
		    Log.d("AndroidNative", " FileName: " + FileName);
		    Log.d("AndroidNative", "is esixts: " + file.exists());
	        
	        
	        
		     
	        fOut = new FileOutputStream(file);
	       
	        bmp.compress(Bitmap.CompressFormat.JPEG, 100, fOut);
		    
	        fOut.flush();
	        fOut.close();
	        
	      //  File f = new File(imageRoot + name);
	        
	        

	      //  String timeStamp = new SimpleDateFormat("yyyyMMdd_HHmmss").format(new Date());
		    ContentValues values = new ContentValues();
		    values.put(Images.Media.TITLE, name);
		    values.put(Images.Media.DESCRIPTION, "");
		    values.put(Images.Media.DATE_TAKEN, System.currentTimeMillis ());
		    values.put(Images.ImageColumns.BUCKET_ID, file.toString().toLowerCase(Locale.US).hashCode());
		    values.put(Images.ImageColumns.BUCKET_DISPLAY_NAME, file.getName().toLowerCase(Locale.US));
		    values.put("_data", file.getAbsolutePath());

		    ContentResolver cr = AndroidNativeBridge.GetInstance().getContentResolver();
		    Uri path = cr.insert(MediaStore.Images.Media.EXTERNAL_CONTENT_URI, values);
		    Log.d("AndroidNative", "Saved: " + path.toString());
			
		    UnityPlayer.UnitySendMessage(CAMERA_SERVICE_LISTNER_NAME, "OnImageSavedEvent", path.toString());
		    
		    
		    
		    //scan just created photo:
		    Intent mediaScanIntent = new Intent(Intent.ACTION_MEDIA_SCANNER_SCAN_FILE);
		    mediaScanIntent.setData(path);
		    AndroidNativeBridge.GetInstance().sendBroadcast(mediaScanIntent);
		
		} catch (Exception e) {
			Log.d("AndroidNative", "Not saved");
			UnityPlayer.UnitySendMessage(CAMERA_SERVICE_LISTNER_NAME, "OnImageSaveFailedEvent", "");
			e.printStackTrace();
			
		}
	}
	
	public byte[] getBytesFromBitmap(Bitmap bitmap) {
	    ByteArrayOutputStream stream = new ByteArrayOutputStream();
	    bitmap.compress(CompressFormat.PNG, 70, stream);
	    return stream.toByteArray();
	}

	// get the base 64 string
	
	@SuppressLint("NewApi") 
	private void galleryAddPic() {
	    Intent mediaScanIntent = new Intent(Intent.ACTION_MEDIA_SCANNER_SCAN_FILE);
	    File f = new File(mCurrentPhotoPath);
	    Uri contentUri = Uri.fromFile(f);
	    mediaScanIntent.setData(contentUri);
	    AndroidNativeBridge.GetInstance().sendBroadcast(mediaScanIntent);
	}
	
	
	
	@SuppressLint("NewApi")
	public void onActivityResult(int requestCode, int resultCode, Intent data) {

		StringBuilder result = null;
		
		if(requestCode == ChooserType.REQUEST_PICK_PICTURE) {
			if(resultCode == Activity.RESULT_OK) {
				 imageChooserManager.submit(requestCode, data);
			} else {
				result = new StringBuilder();
				result.append(resultCode);
				result.append(AndroidNativeBridge.UNITY_SPLITTER);
				result.append("");
				UnityPlayer.UnitySendMessage(CAMERA_SERVICE_LISTNER_NAME, "OnImagePickedEvent", result.toString()); 
			}
			
			return;
		}
		
		
		
		if (requestCode == RESULT_IMAGE_CAPTURE )  {
			
			Log.d("AndroidNative", "RESULT_IMAGE_CAPTURE captured ");
			result = new StringBuilder();
			result.append(resultCode);
			result.append(AndroidNativeBridge.UNITY_SPLITTER);
			
			if( resultCode == Activity.RESULT_OK) {
				
				if(TakeFullSizePhoto) {
					   galleryAddPic();
					   
					   File img = new File(mCurrentPhotoPath);
					   Log.d("AndroidNative", "image is exsist: " + img.exists());
					   Log.d("AndroidNative", "image size: " + img.length());
					 
					   BitmapFactory.Options bmOptions = new BitmapFactory.Options();
					   bmOptions.inJustDecodeBounds = true;
					   
					   BitmapFactory.decodeFile(mCurrentPhotoPath, bmOptions);
					
					   int photoW = bmOptions.outWidth;
					  
					   
					   int scaleFactor = photoW/MaxImageAllowedSize;
					   
					   bmOptions.inJustDecodeBounds = false;
					   bmOptions.inSampleSize = scaleFactor;
					   bmOptions.inPurgeable = true;

					   
					   
					   Bitmap b = BitmapFactory.decodeFile(mCurrentPhotoPath, bmOptions);
					  
					   Log.d("AndroidNative", "w: " + b.getWidth() + " h: " + b.getHeight());
					   String imgString = Base64.encode(getBytesFromBitmap(b));
					   result.append(imgString);
					   
					   
				} else {
					if(data != null) {
						Bundle extras = data.getExtras();
						Bitmap b = (Bitmap) extras.get("data");
						
						Log.d("AndroidNative", "w: " + b.getWidth() + " h: " + b.getHeight());
						String imgString = Base64.encode(getBytesFromBitmap(b));
				   
						result.append(imgString);
					} else {
						result.append("");
					}
					
				}
				
				
			} else {
				result.append("");
			}
			
			UnityPlayer.UnitySendMessage(CAMERA_SERVICE_LISTNER_NAME, "OnImagePickedEvent", result.toString()); 
		}

	}
	

	
	@SuppressLint("NewApi")
	public void GetImageFromGallery() {
		

		try {
			imageChooserManager  =  new ImageChooserManager(AndroidNativeBridge.GetInstance(), ChooserType.REQUEST_PICK_PICTURE);
			imageChooserManager.setImageChooserListener(this);
			imageChooserManager.choose();
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
	
	
	@SuppressLint("NewApi")
	public void GetImageFromCamera() {
		Log.d("AndroidNative", "GetImageFromCamera: ");
		Intent takePictureIntent = new Intent(MediaStore.ACTION_IMAGE_CAPTURE);
	    if (takePictureIntent.resolveActivity(AndroidNativeBridge.GetInstance().getPackageManager()) != null) {
	    	
	    	if(TakeFullSizePhoto) {
	    		 File photoFile = createImageFile();
	    	     // Continue only if the File was successfully created
	    	     if (photoFile != null) {
	    	    	   Log.d("AndroidNative", "Getting full size photo: ");
	    	           takePictureIntent.putExtra(MediaStore.EXTRA_OUTPUT, Uri.fromFile(photoFile));
	    	           AndroidNativeBridge.GetInstance().startActivityForResult(takePictureIntent, RESULT_IMAGE_CAPTURE);
	    	     } else {
	    	    	 TakeFullSizePhoto = false;
	    	    	 AndroidNativeBridge.GetInstance().startActivityForResult(takePictureIntent, RESULT_IMAGE_CAPTURE);
	    	     }
	    	} else {
	    		AndroidNativeBridge.GetInstance().startActivityForResult(takePictureIntent, RESULT_IMAGE_CAPTURE);
	    	}
	    	
	    	
	    }
	}
	
	
	
	
	private String mCurrentPhotoPath;
	
	
	private File createImageFile()  {
	    // Create an image file name
	    String timeStamp = new SimpleDateFormat("yyyyMMdd_HHmmss").format(new Date());
	    String imageFileName = "JPEG_CAMERASHOT_" + timeStamp;
	    File imageRoot = new File(Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_PICTURES), GalleryFolderName);
	    imageRoot.mkdirs();
	    
	  
	    File image = null;
		try {
			image = File.createTempFile(
			    imageFileName,  /* prefix */
			    ".jpg",         /* suffix */
			    imageRoot      /* directory */
			);
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

	    // Save a file: path for use with ACTION_VIEW intents
	    mCurrentPhotoPath = "file:" + image.getAbsolutePath();
	    mCurrentPhotoPath = image.getAbsolutePath();
		   
	    return image;
	}
	
	

	@Override
	public void onError(String arg0) {
		Log.d("AndroidNative", "chooser onError: ");
		StringBuilder result = new StringBuilder();
		result.append(Activity.RESULT_OK);
		result.append(AndroidNativeBridge.UNITY_SPLITTER);
		result.append("");
		UnityPlayer.UnitySendMessage(CAMERA_SERVICE_LISTNER_NAME, "OnImagePickedEvent", result.toString()); 
	}

	@Override
	public void onImageChosen(ChosenImage image) {
		 
		Log.d("AndroidNative", "onImageChosen: ");
		
		StringBuilder result = null;
		result = new StringBuilder();
		result.append(Activity.RESULT_OK);
		result.append(AndroidNativeBridge.UNITY_SPLITTER);
		
		
		
		String imgString = "";
		if(image != null) {
			
			BitmapFactory.Options bmOptions = new BitmapFactory.Options();
			bmOptions.inJustDecodeBounds = true;
   
		   BitmapFactory.decodeFile(image.getFilePathOriginal(), bmOptions);
		
		   int photoW = bmOptions.outWidth;
		   int scaleFactor = photoW/MaxImageAllowedSize;
		   
		   bmOptions.inJustDecodeBounds = false;
		   bmOptions.inSampleSize = scaleFactor;
		   bmOptions.inPurgeable = true;
		   Bitmap b = BitmapFactory.decodeFile(image.getFilePathOriginal(), bmOptions);
			   
			
			imgString = Base64.encode(getBytesFromBitmap(b));
			Log.d("AndroidNative", "w: " + b.getWidth() + " h: " + b.getHeight());
			Log.d("AndroidNative", "Bitmap: " + b);
		} 
		result.append(imgString);
		UnityPlayer.UnitySendMessage(CAMERA_SERVICE_LISTNER_NAME, "OnImagePickedEvent", result.toString()); 

       
		// TODO Auto-generated method stub
		
	}
	
	
}

package com.androidnative.gms.utils;

import java.io.IOException;

import com.androidnative.gms.core.GameClientManager;
import com.google.android.gms.ads.identifier.AdvertisingIdClient;
import com.google.android.gms.ads.identifier.AdvertisingIdClient.Info;
import com.google.android.gms.common.GooglePlayServicesNotAvailableException;
import com.google.android.gms.common.GooglePlayServicesRepairableException;
import com.unity3d.player.UnityPlayer;

import android.os.AsyncTask;

public class PS_Utility {
	
	
	public static String UTIL_LISTNER_NAME = "GooglePlayUtils";

	
	public static void GetAdvertisingId() {
		AsyncTask<Void, Void, Void> task = new AsyncTask<Void, Void, Void>() {

			@Override
			protected Void doInBackground(Void... params) {
				
				String id = "";
				boolean isLAT = false;
				  
				
				Info adInfo = null;
				  try {
						adInfo = AdvertisingIdClient.getAdvertisingIdInfo(AnUtility.GetApplicationContex());
						id = adInfo.getId();
						isLAT = adInfo.isLimitAdTrackingEnabled();
				  } catch (IOException e) {
				    // Unrecoverable error connecting to Google Play services (e.g.,
				    // the old version of the service doesn't support getting AdvertisingId).
					  
				  } catch (IllegalStateException e) {
						// TODO Auto-generated catch block
						e.printStackTrace();
				 
				  } catch (GooglePlayServicesNotAvailableException e) {
				    // Google Play services is not available entirely.
				  } catch (GooglePlayServicesRepairableException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
	  
				  
				  StringBuilder info = new StringBuilder();

				  
				  info.append(id);
				  info.append(GameClientManager.UNITY_SPLITTER);
				  if(isLAT) {
					  info.append("true");
				  } else {
					  info.append("false");
				  }
					
				  UnityPlayer.UnitySendMessage(UTIL_LISTNER_NAME, "OnAdvertisingIdLoaded", info.toString());
				  
				return null;
			}
			
			
		};
		
		task.execute();
	}
}

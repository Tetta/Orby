<?php


// API access key from Google API's Console
define( 'API_ACCESS_KEY', 'AIzaSyC6MC2SvJSX7YeRw_FQnPieid6stE7TMTI' );


$registrationIds = array("APA91bEHs-XoUSk_RSXub1510Segbnf6_87-EueujgAyXtKDVZDrY2iZD37gghNEzzbLdzFpyXsAgLSLXnve_bQPoZ8q3P3vAplBMh5UDIJfroCUpi58ZKEzrCAJbFQyv2aNjl4FRLjV_NO0z4QZ2iLGfTPDiELgLL_kwYsPj56tCg-eXkYrJIA");

// prep the bundle
$msg = array
(
    'title'         => 'This is a title. title',
    'subtitle'      => 'This is a subtitle. subtitle',
    'message'       => 'here is a message. message'
);

$fields = array
(
    'registration_ids'  => $registrationIds,
    'data'              => $msg
);

$headers = array
(
    'Authorization: key=' . API_ACCESS_KEY,
    'Content-Type: application/json'
);

$ch = curl_init();
curl_setopt( $ch,CURLOPT_URL, 'https://android.googleapis.com/gcm/send' );
curl_setopt( $ch,CURLOPT_POST, true );
curl_setopt( $ch,CURLOPT_HTTPHEADER, $headers );
curl_setopt( $ch,CURLOPT_RETURNTRANSFER, true );
curl_setopt( $ch,CURLOPT_SSL_VERIFYPEER, false );
curl_setopt( $ch,CURLOPT_POSTFIELDS, json_encode( $fields ) );
$result = curl_exec($ch );
curl_close( $ch );

echo $result;
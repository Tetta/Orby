package com.androidnative.gms.listeners.quests;

import java.util.Iterator;

import android.util.Log;

import com.androidnative.AndroidNativeBridge;
import com.androidnative.gms.core.GameClientManager;
import com.google.android.gms.common.api.ResultCallback;
import com.google.android.gms.games.GamesStatusCodes;
import com.google.android.gms.games.event.Event;
import com.google.android.gms.games.event.Events;
import com.google.android.gms.games.event.Events.LoadEventsResult;
import com.unity3d.player.UnityPlayer;

public class AN_EventsLoadListner implements ResultCallback<Events.LoadEventsResult> {

	@Override
	public void onResult(LoadEventsResult r) {
		
		Log.d(AndroidNativeBridge.TAG, "AN_EventsLoadListner+");
		// TODO Auto-generated method stub
		
		int statusCode = r.getStatus().getStatusCode();
		StringBuilder result = new StringBuilder();
		result.append(statusCode);
		
		if (statusCode == GamesStatusCodes.STATUS_OK) {
			result.append(AndroidNativeBridge.UNITY_SPLITTER);
			
			Iterator<Event> iterator = r.getEvents().iterator();
			while (iterator.hasNext()) {
				
				Event event = iterator.next();
				result.append(event.getEventId());
				result.append(AndroidNativeBridge.UNITY_SPLITTER);
				result.append(event.getDescription());
				result.append(AndroidNativeBridge.UNITY_SPLITTER);
				result.append(event.getIconImageUrl());
				result.append(AndroidNativeBridge.UNITY_SPLITTER);
				result.append(event.getFormattedValue());
				result.append(AndroidNativeBridge.UNITY_SPLITTER);
				result.append(Long.toString(event.getValue()));
				result.append(AndroidNativeBridge.UNITY_SPLITTER);
				
				
			}
			
			r.getEvents().close();
			result.append(AndroidNativeBridge.UNITY_EOF);
		}
		
		UnityPlayer.UnitySendMessage(GameClientManager.GOOGLE_PlAY_EVENTS_LISTNER_NAME, "OnGPEventsLoaded", result.toString());
	}

}
